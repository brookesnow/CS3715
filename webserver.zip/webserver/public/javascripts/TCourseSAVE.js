/**
 * http://usejsdoc.org/
 */
function getdata(){
	var url = "TCourses.js";
	var request = new XMLHttpRequest();
	request.open("POST", url);
	request.onload = function() {
		if (request.status == 200) {
			updateSales(request.responseText);
		}
	};
	request.send(Tvalue);
	
}