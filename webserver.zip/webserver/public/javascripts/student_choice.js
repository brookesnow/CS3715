/**
 * http://usejsdoc.org/
 */
window.onload = init;

function init(){
	var button = document.getElementById("testing");
	button.onclick = loadStudent;
}

function loadStudent(){
	var select = document.getElementById("selection")
	
	if(select.options[select.selectedIndex].text== "Adam"){
		window.location.replace("Adam.html");
	}
	if(select.options[select.selectedIndex].text== "Brooke"){
		window.location.replace("Brooke.html");
	}
	if(select.options[select.selectedIndex].text== "Mike"){
		window.location.replace("Mike.html");
	}
	if(select.options[select.selectedIndex].text== "Bobert"){
		window.location.replace("Bobert.html");
	}
	if(select.options[select.selectedIndex].text== "Kelly"){
		window.location.replace("Kelly.html");
	}
	
}