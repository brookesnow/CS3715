window.onload = init;


function init(){
	var title = document.getElementsByTagName("title")[0].innerHTML;
	if(title  == "Arts Campus Previous Course Catalog"){
		var AdeletedArray = getDeletedArray();
		for(var i = 0; i <= AdeletedArray.length; i++){
		addToPrevious(AdeletedArray[i]);
		}
	}
	if(title == "Arts Campus Course Catalog"){
	
	var submitButton = document.getElementById("submitButton");
	submitButton.onclick = createCourseName;
	var x = 0;
	var y = 0;
	var AcourseNameArray = getCourseNameArray();
	var AcourseNumArray = getCourseNumArray();
	var AroomArray = getRoomArray();
	var AdeletedArray = getDeletedArray();
	
	for(var i = 0; i < AcourseNameArray.length; i++){
		var Akey = AcourseNameArray[i];
		var value = localStorage[Akey];
		addCourseNameToDOM(Akey,value);
		for(x; x <= i; x++){
			var Akey1 = AcourseNumArray[x];
			var Avalue1 = localStorage[Akey1];
			addCourseNumToDOM(Akey1,Avalue1);
		}
		for(y; y <= i ; y++){
			var Akey2 = AroomArray[y];
			var Avalue2 = localStorage[Akey2];
			addRoomToDOM(Akey2,Avalue2);
		}
	}
	
	var button = document.getElementById("reg_button");
	button.onclick = createRegister;
	
	var registersArray = getRegistersArray();
	
	for(var i = 0; i < registersArray.length; i++){
		var key = registersArray[i];
		var value = localStorage[key];
		addRegisterToDOM(key,value);
	}
	
}


function getCourseNameArray(){
	
	var AcourseNameArray = localStorage.getItem("AcourseNameArray");
	if(!AcourseNameArray){
		
		AcourseNameArray = [];
		localStorage.setItem("AcourseNameArray", JSON.stringify(AcourseNameArray));
		
	} else {
		AcourseNameArray = JSON.parse(AcourseNameArray);
	}
	
	return AcourseNameArray;
}

function getCourseNumArray(){
	
	var AcourseNumArray = localStorage.getItem("AcourseNumArray");
	if(!AcourseNumArray){
		
		AcourseNumArray = [];
		localStorage.setItem("AcourseNumArray", JSON.stringify(AcourseNumArray));
		
	} else {
		AcourseNumArray = JSON.parse(AcourseNumArray);
	}
	
	return AcourseNumArray;
}

function getRoomArray(){
	
	var AroomArray = localStorage.getItem("AroomArray");
	if(!AroomArray){
		
		AroomArray = [];
		localStorage.setItem("AroomArray", JSON.stringify(AroomArray));
		
	} else {
		AroomArray = JSON.parse(AroomArray);
	}
	
	return AroomArray;
}

function getDeletedArray(){
	var AdeletedArray = localStorage.getItem("AdeletedArray");
	if(!AdeletedArray){
		
		AdeletedArray = [];
		localStorage.setItem("AdeletedArray", JSON.stringify(AdeletedArray));
		
	} else {
		AdeletedArray = JSON.parse(AdeletedArray);
	}
	
	return AdeletedArray;
		}


function createCourseName(){
	var courseNameArray = getCourseNameArray();
	var courseNumArray = getCourseNumArray();
	var AroomArray = getRoomArray();
	var currentDate = new Date();
	var currentDate2 = new Date();
	var currentDate3 = new Date();
	var Akey = "courseName_" + currentDate.getTime();
	var Akey1 = "courseNum_" + currentDate2.getTime();
	var Akey2 = "room_" + currentDate3.getTime();
	
	var Avalue = document.getElementById("courseName").value;
	var Avalue1 = document.getElementById("courseNum").value;
	var Avalue2 = document.getElementById("room").value;
	localStorage.setItem(Akey, Avalue);
	localStorage.setItem(Akey1,Avalue1);
	localStorage.setItem(Akey2, Avalue2);
	
	AcourseNameArray.push(Akey);
	AcourseNumArray.push(Akey1);
	AroomArray.push(Akey2);
	localStorage.setItem("AcourseNameArray", JSON.stringify(AcourseNameArray));
	localStorage.setItem("AcourseNumArray", JSON.stringify(AcourseNumArray));
	localStorage.setItem("AroomArray", JSON.stringify(AroomArray));
	
	addCourseNameToDOM(Akey,Avalue);
	addCourseNumToDOM(Akey1,Avalue1);
	addRoomToDOM(Akey2,Avalue2);
}

function addCourseNameToDOM(Akey, Avalue){
	var Atable = document.getElementById("courseTable");
	var Acoursename = document.createElement("TD");
	var Arow = document.createElement("TR");
	Acoursename.setAttribute("id", Akey);
	var span = document.createElement("span");
	span.innerHTML = Avalue;
	Acoursename.innerHTML = Avalue;
	Atable.appendChild(Arow);
	Atable.appendChild(Acoursename);
	Acoursename.onclick = deleteCourseName;
}

function addCourseNumToDOM(Akey1, Avalue1){
	var Atable = document.getElementById("courseTable");
	var Acoursenum = document.createElement("TD");
	Acoursenum.setAttribute("id", Akey1);
	var span1 = document.createElement("span1");
	span1.innerHTML = Avalue1;
	Acoursenum.innerHTML = Avalue1;
	Atable.appendChild(Acoursenum);
}

function addRoomToDOM(Akey2, Avalue2){
	var Atable = document.getElementById("courseTable");
	var Aroom = document.createElement("TD");
	Aroom.setAttribute("id", Akey2);
	var span2 = document.createElement("span2");
	span2.innerHTML = Avalue2;
	Aroom.innerHTML = Avalue2;
	Atable.appendChild(Aroom);
}

		
function deleteCourseName(e){
	var AcurrentDate = new Date();
	var AdeletedArray = getDeletedArray();
	var Akey = e.target.id;
	var Avalue1 ="Course: " + e.target.textContent + " Time Deleted: " + AcurrentDate;
	if(e.target.tagName.toLowerCase() == "span"){
		Akey = e.target.parentNode.id;
	}
	
	AdeletedArray.push(Avalue1);
	localStorage.setItem("AdeletedArray", JSON.stringify(AdeletedArray));
	localStorage.removeItem(Akey);
	var AcourseNameArray = getCourseNameArray();
	var AcourseNumArray = getCourseNumArray();
	var AroomArray = getRoomArray();
	if(AcourseNameArray){
		for(var i = 0; i < AcourseNameArray.length; i++){
			if(Akey == AcourseNameArray[i]){
				AcourseNameArray.splice(i,1);
				localStorage.removeItem(AcourseNumArray[i]);
				localStorage.removeItem(AroomArray[i]);
				AcourseNumArray.splice(i, 1);
				AroomArray.splice(i,1);
				
			}
		}
		
		localStorage.setItem("AcourseNameArray", JSON.stringify(AcourseNameArray));
		localStorage.setItem("AcourseNumArray", JSON.stringify(AcourseNumArray));
		localStorage.setItem("AroomArray", JSON.stringify(AroomArray));
		removeCourseNameFromDOM(Akey);
		AdeletedArray.splice(0,1);
		addToPrevious(Avalue1);
			
	}
}
	
	function removeCourseNameFromDOM(Akey){
		var Acoursename = document.getElementById(Akey);
		Acoursename.parentNode.removeChild(Acoursename);
		location.reload(true);
	}
	
	function addToPrevious(a){
		
		var Alist = document.getElementById("artsPre");
		var Aitem = document.createElement("li");
		Aitem.setAttribute("id", a);
		var span2 = document.createElement("span2");
		span2.innerHTML = a.value;
		Aitem.innerHTML = a;
		Alist.appendChild(Aitem);
	}
	
function getRegistersArray(){
		
		var registersArray = localStorage.getItem("registersArray");
		if(!registersArray){
			
			registersArray = [];
			localStorage.setItem("registersArray", JSON.stringify(registersArray));
			
		} else {
			registersArray = JSON.parse(registersArray);
		}
		
		return registersArray;
	}

	function createRegister(){
		
		var registersArray = getRegistersArray();
		var currentDate = new Date();
		var key = "register_" + currentDate.getTime();
		
		var value = document.getElementById("courseNumb").value;
		localStorage.setItem(key, value);
		
		registersArray.push(key);
		localStorage.setItem("registersArray", JSON.stringify(registersArray));
		
		addRegisterToDOM(key,value);
		
	}

	function addRegisterToDOM(key, value){
		var registers = document.getElementById("registers_list");
		var register = document.createElement("li");
		register.setAttribute("id", key);
		var span = document.createElement("span");
		span.setAttribute("class", "register");
		span.innerHTML = value;
		register.appendChild(span);
		registers.appendChild(register);
		register.onclick = deleteRegister;
	}

	function deleteRegister(e){
		
		var key = e.target.id;
		if(e.target.tagName.toLowerCase() == "span"){
			key = e.target.parentNode.id;
		}
		
		localStorage.removeItem(key);
		var registersArray = getRegistersArray();
		if(registersArray){
			for(var i = 0; i < registersArray.length; i++){
				if(key == registersArray[i]){
					registersArray.splice(i,1);
				}
			}
			
			localStorage.setItem("registersArray", JSON.stringify(registersArray));
			removeRegisterFromDOM(key);
				
		}
	}

	function removeRegisterFromDOM(key){
		var register = document.getElementById(key);
		register.parentNode.removeChild(register);
	}
}

