window.onload = init;


function init(){
	var title = document.getElementsByTagName("title")[0].innerHTML;
	if(title  == "Technology Campus Previous Course Catalog"){
		var TdeletedArray = getDeletedArray();
		for(var i = 0; i <= TdeletedArray.length; i++){
		addToPrevious(TdeletedArray[i]);
		}
	}
	if(title == "Technology Campus Course Catalog"){
	
	var submitButton = document.getElementById("submitButton");
	submitButton.onclick = createCourseName;
	var x = 0;
	var y = 0;
	var TcourseNameArray = getCourseNameArray();
	var TcourseNumArray = getCourseNumArray();
	var TroomArray = getRoomArray();
	var TdeletedArray = getDeletedArray();
	
	for(var i = 0; i < TcourseNameArray.length; i++){
		var Tkey = TcourseNameArray[i];
		var value = localStorage[Tkey];
		addCourseNameToDOM(Tkey,value);
		for(x; x <= i; x++){
			var Tkey1 = TcourseNumArray[x];
			var value1 = localStorage[Tkey1];
			addCourseNumToDOM(Tkey1,value1);
		}
		for(y; y <= i ; y++){
			var Tkey2 = TroomArray[y];
			var value2 = localStorage[Tkey2];
			addRoomToDOM(Tkey2,value2);
		}
	}
	var button = document.getElementById("reg_button");
	button.onclick = createRegister;
	
	var registersArray = getRegistersArray();
	
	for(var i = 0; i < registersArray.length; i++){
		var key = registersArray[i];
		var value = localStorage[key];
		addRegisterToDOM(key,value);
	}
	
}


function getCourseNameArray(){
	
	var TcourseNameArray = localStorage.getItem("TcourseNameArray");
	if(!TcourseNameArray){
		
		TcourseNameArray = [];
		localStorage.setItem("TcourseNameArray", JSON.stringify(TcourseNameArray));
		
	} else {
		TcourseNameArray = JSON.parse(TcourseNameArray);
	}
	
	return TcourseNameArray;
}

function getCourseNumArray(){
	
	var TcourseNumArray = localStorage.getItem("TcourseNumArray");
	if(!TcourseNumArray){
		
		TcourseNumArray = [];
		localStorage.setItem("TcourseNumArray", JSON.stringify(TcourseNumArray));
		
	} else {
		TcourseNumArray = JSON.parse(TcourseNumArray);
	}
	
	return TcourseNumArray;
}

function getRoomArray(){
	
	var TroomArray = localStorage.getItem("TroomArray");
	if(!TroomArray){
		
		TroomArray = [];
		localStorage.setItem("TroomArray", JSON.stringify(TroomArray));
		
	} else {
		TroomArray = JSON.parse(TroomArray);
	}
	
	return TroomArray;
}

function getDeletedArray(){
	var TdeletedArray = localStorage.getItem("TdeletedArray");
	if(!TdeletedArray){
		
		TdeletedArray = [];
		localStorage.setItem("TdeletedArray", JSON.stringify(TdeletedArray));
		
	} else {
		TdeletedArray = JSON.parse(TdeletedArray);
	}
	
	return TdeletedArray;
		}


function createCourseName(){
	var courseNameArray = getCourseNameArray();
	var courseNumArray = getCourseNumArray();
	var TroomArray = getRoomArray();
	var currentDate = new Date();
	var currentDate2 = new Date();
	var currentDate3 = new Date();
	var Tkey = "courseName_" + currentDate.getTime();
	var Tkey1 = "courseNum_" + currentDate2.getTime();
	var Tkey2 = "room_" + currentDate3.getTime();
	
	var Tvalue = document.getElementById("courseName").value;
	var Tvalue1 = document.getElementById("courseNum").value;
	var Tvalue2 = document.getElementById("room").value;
	localStorage.setItem(Tkey, Tvalue);
	localStorage.setItem(Tkey1,Tvalue1);
	localStorage.setItem(Tkey2, Tvalue2);
	
	TcourseNameArray.push(Tkey);
	TcourseNumArray.push(Tkey1);
	TroomArray.push(Tkey2);
	localStorage.setItem("TcourseNameArray", JSON.stringify(TcourseNameArray));
	localStorage.setItem("TcourseNumArray", JSON.stringify(TcourseNumArray));
	localStorage.setItem("TroomArray", JSON.stringify(TroomArray));
	
	addCourseNameToDOM(Tkey,Tvalue);
	addCourseNumToDOM(Tkey1,Tvalue1);
	addRoomToDOM(Tkey2,Tvalue2);
}

function addCourseNameToDOM(Tkey, Tvalue){
	var Ttable = document.getElementById("courseTable");
	var Tcoursename = document.createElement("TD");
	var Trow = document.createElement("TR");
	Tcoursename.setAttribute("id", Tkey);
	var span = document.createElement("span");
	span.innerHTML = Tvalue;
	Tcoursename.innerHTML = Tvalue;
	Ttable.appendChild(Trow);
	Ttable.appendChild(Tcoursename);
	Tcoursename.onclick = deleteCourseName;
}

function addCourseNumToDOM(Tkey1, Tvalue1){
	var Ttable = document.getElementById("courseTable");
	var Tcoursenum = document.createElement("TD");
	Tcoursenum.setAttribute("id", Tkey1);
	var span1 = document.createElement("span1");
	span1.innerHTML = Tvalue1;
	Tcoursenum.innerHTML = Tvalue1;
	Ttable.appendChild(Tcoursenum);
}

function addRoomToDOM(Tkey2, Tvalue2){
	var Ttable = document.getElementById("courseTable");
	var Troom = document.createElement("TD");
	Troom.setAttribute("id", Tkey2);
	var span2 = document.createElement("span2");
	span2.innerHTML = Tvalue2;
	Troom.innerHTML = Tvalue2;
	Ttable.appendChild(Troom);
}

		
function deleteCourseName(e){
	var TcurrentDate = new Date();
	var TdeletedArray = getDeletedArray();
	var Tkey = e.target.id;
	var Tvalue1 ="Course: " + e.target.textContent + " Time Deleted: " + TcurrentDate;
	if(e.target.tagName.toLowerCase() == "span"){
		Tkey = e.target.parentNode.id;
	}
	
	TdeletedArray.push(Tvalue1);
	localStorage.setItem("TdeletedArray", JSON.stringify(TdeletedArray));
	localStorage.removeItem(Tkey);
	var TcourseNameArray = getCourseNameArray();
	var TcourseNumArray = getCourseNumArray();
	var TroomArray = getRoomArray();
	if(TcourseNameArray){
		for(var i = 0; i < TcourseNameArray.length; i++){
			if(Tkey == TcourseNameArray[i]){
				TcourseNameArray.splice(i,1);
				localStorage.removeItem(TcourseNumArray[i]);
				localStorage.removeItem(TroomArray[i]);
				TcourseNumArray.splice(i, 1);
				TroomArray.splice(i,1);
				
			}
		}
		
		localStorage.setItem("TcourseNameArray", JSON.stringify(TcourseNameArray));
		localStorage.setItem("TcourseNumArray", JSON.stringify(TcourseNumArray));
		localStorage.setItem("TroomArray", JSON.stringify(TroomArray));
		removeCourseNameFromDOM(Tkey);
		TdeletedArray.splice(0,1);
		addToPrevious(Tvalue1);
			
	}
}
	
	function removeCourseNameFromDOM(Tkey){
		var Tcoursename = document.getElementById(Tkey);
		Tcoursename.parentNode.removeChild(Tcoursename);
		location.reload(true);
	}
	
	function addToPrevious(a){
		
		var Tlist = document.getElementById("techPre");
		var Titem = document.createElement("li");
		Titem.setAttribute("id", a);
		var span2 = document.createElement("span2");
		span2.innerHTML = a.value;
		Titem.innerHTML = a;
		Tlist.appendChild(Titem);
	}
function getRegistersArray(){
		
		var registersArray = localStorage.getItem("registersArray");
		if(!registersArray){
			
			registersArray = [];
			localStorage.setItem("registersArray", JSON.stringify(registersArray));
			
		} else {
			registersArray = JSON.parse(registersArray);
		}
		
		return registersArray;
	}

	function createRegister(){
		
		var registersArray = getRegistersArray();
		var currentDate = new Date();
		var key = "register_" + currentDate.getTime();
		
		var value = document.getElementById("courseNumb").value;
		localStorage.setItem(key, value);
		
		registersArray.push(key);
		localStorage.setItem("registersArray", JSON.stringify(registersArray));
		
		addRegisterToDOM(key,value);
		
	}

	function addRegisterToDOM(key, value){
		var registers = document.getElementById("registers_list");
		var register = document.createElement("li");
		register.setAttribute("id", key);
		var span = document.createElement("span");
		span.setAttribute("class", "register");
		span.innerHTML = value;
		register.appendChild(span);
		registers.appendChild(register);
		register.onclick = deleteRegister;
	}

	function deleteRegister(e){
		
		var key = e.target.id;
		if(e.target.tagName.toLowerCase() == "span"){
			key = e.target.parentNode.id;
		}
		
		localStorage.removeItem(key);
		var registersArray = getRegistersArray();
		if(registersArray){
			for(var i = 0; i < registersArray.length; i++){
				if(key == registersArray[i]){
					registersArray.splice(i,1);
				}
			}
			
			localStorage.setItem("registersArray", JSON.stringify(registersArray));
			removeRegisterFromDOM(key);
				
		}
	}

	function removeRegisterFromDOM(key){
		var register = document.getElementById(key);
		register.parentNode.removeChild(register);
	}
	
	function createEntireArray(){
		var array = createCourseName();
	}
}


